<html>
<head>
<style>
.mainform{
	margin-top:130px;
	display:flex;
	height:150%;
	width:100%;
}
.vidget{
	margin-top:30px;
	margin-left:500px;
	width:420px; /* Размеры */
	outline: 2px solid #333333; /* Чёрная рамка */
    border: 1px solid #333333; /* Белая рамка */
    border-radius: 10px; /* Радиус скругления */
	background-color:#212529;
}
.vidgetform{
	display:block;
	max-width:200px;
}
.vidgetinput{
	background-color:#333333;
	color:white;
	border: 1px solid #212529;
	margin-left:6px;
	margin-top:5px;
	width:405px;
	border-radius: 5px;
	font-size:18px;
}
.select:hover{
	border-color:white;
	 transition: 1s;
}
.select:not(:hover){

	 transition: 1s;
}
.vidgetinput:hover{
	border-color:white;
	 transition: 1s;
}
.vidgetinput:not(:hover){

	 transition: 1s;
}
.textaform{
	margin-top:50px;
	color:white;
	font-family: 'Open Sans', sans-serif;
	font-size:25px;
	margin-left:135px;
}
.oformit{
	background-color:#39adff;
}
.check{
	margin-left:20px;
}
.prin{
	line-height:3;
}
</style>
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<link href="styles.css" media="screen" rel="stylesheet" type="text/css">
<div class="container">
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarTogglerDemo01"
      aria-controls="navbarTogglerDemo01"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <a class="navbar-brand" href="index.php" style="margin-left: 20px">Область</a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

      <form class="d-flex input-group w-auto" style="margin-left:1600px; padding-top: 15px">
        <a class="btn btn-outline-primary" type="submit" href="reg.php" data-mdb-ripple-color="dark">Личный кабинет</a>
      </form>
    </div>
  </div>

</nav>
</div>
</head>
<body style="background-color: white">
  <div class="mainform" >
  <div class="vidgetform">
  <form action="registr.php" method="post" class="vidget" style="margin-left:750px; height:445px; margin-top:160px;" >
  <input name="name" class="vidgetinput" type="text" placeholder="Имя" required >
  <input name="lastname" class="vidgetinput" type="text" placeholder="Фамилия"  required>
  <input name="middlename" class="vidgetinput" type="text" placeholder="Отчество"  required>
  <input name="login" class="vidgetinput" type="text" placeholder="Логин"  required>
  <input name="email" class="vidgetinput" type="text" placeholder="Почта"  type="email" required>
  <input name="password" class="vidgetinput"  placeholder="Пароль"  type="password" required>
  <input name="repassword" class="vidgetinput"  placeholder="Повтор пароля"  type="password" required><br><br>
  <input style="margin-left:7px" class="check prins" type="checkbox" required> <span style="color:white"> Я принимаю условия договора</span></input><br>
  <input style="margin-left:7px; margin-top:15px" class="check prins" type="checkbox" required> <span style="color:white"> Я соглашаюсь на обработку персональных данных</span></input><br>
  <a class="prin" style="margin-left:7px; color:white">Уже есть аккаунт?<a> </a><a class="prin" style="text-decoration:underline; color:white" href="avt.php">Авторизируйтесь!</a><br>
  <button class="vidgetinput oformit" type="submit"  name="submit" value="Регистрация">Регистрация</button>
  </form>
  </div>
  </div>
</body>
</html>
