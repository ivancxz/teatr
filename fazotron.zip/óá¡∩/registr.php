<?php
// Создаем переменные с фильтрами
$name= filter_var(trim($_POST['name']),
 FILTER_SANITIZE_STRING);
$lastname=filter_var(trim($_POST['lastname']),
 FILTER_SANITIZE_STRING);
$middlename=filter_var(trim($_POST['middlename']),
 FILTER_SANITIZE_STRING);
$login=filter_var(trim($_POST['login']),
 FILTER_SANITIZE_STRING);
$email=filter_var(trim($_POST['email']),
 FILTER_SANITIZE_STRING);
$password=filter_var(trim($_POST['password']),
 FILTER_SANITIZE_STRING);
$repassword=filter_var(trim($_POST['repassword']),
 FILTER_SANITIZE_STRING);
// Подключение к бд, а также SQL- запрос
 $mysql = new mysqli('localhost', 'root', '', 'tested');
 $check_user = mysqli_query($mysql, "SELECT  * FROM `reg` WHERE `login` = '$login'");
// Проверка на правильность ввода данных
if(mb_strlen($login) < 3 || mb_strlen($login) > 25){ //проврка правильносати написания логина
  echo "Недопустимя длина логина";
  exit();
} else if(mb_strlen($name) < 3 || mb_strlen($name) > 25){ //проврка правильносати написания имени
  echo "Недопустимя длина имени";
  exit();
} else if(mb_strlen($password) < 3 || mb_strlen($password) > 15){ //проврка правильносати написания пароля
  echo "Недопустимя длина пароля";
  exit();
}
else if(!str_contains($email, '@')){
  echo "Почта должна содержать спец.символ";
  exit();
}
else if($password != $repassword){ //проверка схожести паролей
  echo "Пароли не совпадают";
  exit();
} else if(mysqli_num_rows($check_user) > 1){ //проверка на занятость пароля
  echo "Логин занят!";
  exit();
}
// Хеширование пароля, отправление информации на сервер
$password = md5($password."ygk12345");
$repassword = md5($repassword."ygk12345");
$mysql = new mysqli('localhost', 'root', '', 'tested');
$mysql->query("INSERT INTO `reg` (`name`, `lastname`, `middlename`, `login`, `email`, `password`, `repassword`)
VALUES('$name', '$lastname', '$middlename' , '$login' , '$email' , '$password' , '$repassword')");
$mysql->close();
header('Location: avt.php')

?>
