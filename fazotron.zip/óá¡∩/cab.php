<html>
<head>
<meta charset="utf-8">
<link href="styles.css" media="screen" rel="stylesheet" type="text/css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<div class="container">
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarTogglerDemo01"
      aria-controls="navbarTogglerDemo01"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <a class="navbar-brand" href="#" style="margin-left: 20px">Область</a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

      <form class="d-flex input-group w-auto" style="margin-left:1500px; padding-top: 15px">
        <a class="btn btn-outline-primary" type="submit" href="reg.php" data-mdb-ripple-color="dark">Личный кабинет</a>
      </form>
      <form class="d-flex input-group w-auto" style="margin-left:25px; padding-top: 15px">
        <a class="btn btn-outline-primary" type="submit" href="reg.php" data-mdb-ripple-color="dark">Выйти</a>
      </form>
    </div>
  </div>

</nav>
</div>
</head><br><br><br><br>
<body style="background-color: white">
  <style>
  	table.iksweb{text-decoration: none;border-collapse:collapse;width:100%;text-align:center;}
  	table.iksweb th{font-weight:normal;font-size:22px; color:#000000;background-color:#0095ff;}
  	table.iksweb td{font-size:19px;color:#000000;}
  	table.iksweb td,table.iksweb th{white-space:pre-wrap;padding:11px 9px;line-height:19px;vertical-align: middle;border: 1px solid #000000;}	table.iksweb tr:hover{background-color:#99d5ff}
  	table.iksweb tr:hover td{color:#000000;cursor:default;}
  </style>
  <div class="user">
  <p style="font-size:35px">Вы вошли под логином, <?=$_COOKIE['user'] ?></p>
  </div>
  <table style="margin-top:50px;font-family:Playfair Display" class="iksweb" >
  <thead>
  <tr>
  	<th>Вес груза(кг)</th>
  	<th>Вид груза</th>
  	<th>Тип перевозки</th>
  	<th>Откуда</th>
  	<th>Куда</th>
  	<th>Цена(руб)</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  	<td><?php
  	// Присваиваем переменной логин куки переменную
  	$login=$_COOKIE['user'];
  	$mysql = mysqli_connect('localhost', 'root', '', 'allbd');
  	// Ищем по логину запросом вес груза
  	$result = $mysql->query("SELECT `name` FROM `reguser` WHERE `login` = '$login'");
  	// Выводим в ячейку таблицы
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<p style="font-weight:bold">'.$row['name'].'</p>';
  	}
  	$mysql->close();
  	?></td>

  	<td><?php
  	$mysql = mysqli_connect('localhost', 'root', '', 'allbd');
  	$result = $mysql->query("SELECT `lastname` FROM `reguser` WHERE `login` = '$login'");
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<p style="font-weight:bold">'.$row['lastname'].'</p>';
  	}
  	$mysql->close();
  	?></td>

  	<td><?php
  	$mysql = mysqli_connect('localhost', 'root', '', 'allbd');
  	$result = $mysql->query("SELECT `middlename` FROM `reguser` WHERE `login` = '$login'");
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<p style="font-weight:bold">'.$row['middlename'].'</p>';
  	}
  	$mysql->close();
  	?></td>

  	<td><?php
  	$mysql = mysqli_connect('localhost', 'root', '', 'allbd');
  	$result = $mysql->query("SELECT `login` FROM `reguser` WHERE `login` = '$login'");
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<p style="font-weight:bold">'.$row['login'].'</p>';
  	}
  	$mysql->close();
  	?></td>

  	<td><?php
  	$mysql = mysqli_connect('localhost', 'root', '', 'allbd');
  	$result = $mysql->query("SELECT `email` FROM `reguser` WHERE `login` = '$login'");
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<p style="font-weight:bold">'.$row['email'].'</p>';
  	}
  	$mysql->close();
  	?></td>

  	<td><?php
  	$mysql = mysqli_connect('localhost', 'root', '', 'exam');
  	$result = $mysql->query("SELECT `photo` FROM `photo` WHERE `id` = '1'");
  	while($row = $result->fetch_assoc())
  	{
  	    echo '<img src=',$row['photo'],'>';
  	}
  	$mysql->close();
  	?></td>
  </tr>


  </tbody>
  </table>
</body>
</html>
